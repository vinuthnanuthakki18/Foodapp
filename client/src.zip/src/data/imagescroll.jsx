const images = [
    {
        image : 'scroll1.webp'
    },
    {
        image : 'scroll2.webp'
    },
    {
        image : 'scroll3.webp'
    },
    {
        image : 'scroll4.webp'
    },
    {
        image : 'scroll5.webp'
    },
    {
        image : 'scroll6.webp'
    },
    {
        image : 'scroll7.webp'
    },
    {
        image : 'scroll8.webp'
    },
    {
        image : 'scroll9.webp'
    },
    {
        image : 'scroll10.webp'
    },
    {
        image : 'scroll11.webp'
    },
    {
        image : 'scroll12.webp'
    },
    {
        image : 'scroll13.png'
    },
    {
        image : 'scroll14.webp'
    },
    {
        image : 'scroll15.webp'
    },
    {
        image : 'scroll16.webp'
    },
    {
        image : 'scroll17.webp'
    },
];

export default images;