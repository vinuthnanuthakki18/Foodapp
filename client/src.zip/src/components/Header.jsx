import { useState, useEffect, useRef } from 'react';
import HomeIcon from '@mui/icons-material/Home';
import PersonIcon from '@mui/icons-material/Person';
import { useNavigate } from "react-router-dom";
import Account from './Account';
import './Header.css'
function Header() {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isOpen, setIsOpen] = useState(false);
    const dropdownRef = useRef(null);
    const navigate = useNavigate();
    
    const toggleDropdown = () => {
        setIsOpen(!isOpen);
    };

    useEffect(() => {
        function handleClickOutside(event) {
            if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
                setIsOpen(false);
            }
        }

        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, []);

    return (
        <div className="flex justify-between items-center p-4 h-20 w-full md:px-8">
            <div className="logo-div flex items-center gap-2">
                <img src="/justlogo2.png" alt="logo" className="w-16 h-16 md:w-20 md:h-20 cursor-pointer" onClick={()=>navigate("/")}/>
                <h3 className="text-3xl md:text-4xl text-outline text-orange-500 font-bold cursor-pointer" onClick={()=>navigate("/")}>biteXpress</h3>
            </div>
            <div className="relative flex gap-4 items-center">
                <div className="relative" ref={dropdownRef}>
                    <button
                        onClick={toggleDropdown}
                        className="px-3 py-2 text-sm md:text-base bg-white text-orange-500 rounded shadow-lg  hover:bg-orange-100"
                    >
                        Partner with Us
                    </button>

                    {/* Dropdown */}
                    {isOpen && (
                        <ul className="absolute left-0 mt-2 bg-white shadow-lg rounded w-48 z-50">
                            <li className="px-4 py-2 hover:bg-gray-100 cursor-pointer">Rider</li>
                            <li className="px-4 py-2 hover:bg-gray-100 cursor-pointer">Partners</li>
                            <li className="px-4 py-2 hover:bg-gray-100 cursor-pointer">Users</li>
                            <li className="px-4 py-2 hover:bg-gray-100 cursor-pointer">Food to Work</li>
                        </ul>
                    )}
                </div>
                <button className="px-3 py-2 text-sm md:text-base bg-white text-orange-500 rounded shadow-lg  hover:bg-orange-100 flex items-center gap-1" onClick={()=>navigate("/signup")}>
                    <HomeIcon className=""/>SignUp or Login
                </button>
                
                <button className="px-4 py-2 bg-white text-orange-500 rounded  shadow-lg" onClick={() => setIsModalOpen(true)}>
                    <PersonIcon className="p-1"/>Account
                </button>
                <Account isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
            </div>
        </div>
    );
}

export default Header;
